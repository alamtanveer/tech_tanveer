var data=[{
			"Heading": "Wallet balance is getting low.",
			"content": "Your wallet balance is INR 34.67. which on average will survive 4 more days. Recharge now to avoid.",
			"footerCaption": "ADD MONEY",
			"otherDetails": ""
		},
		{
			"Heading": "5 Tips to Make Your Small Business More Profitable",
			"content": "Looking for ways to make your small business more Profitable? Here are 5 tips to help you achieve that goal and build your small business.",
			"footerCaption": "READ ARTICLE",
			"otherDetails": "(2 min read)"
		},
		{
			"Heading": "A customer is trying to reach you.",
			"content": "I am not able to see my daily visits in the dashboard Is there anyway i can customize my dashboard?",
			"footerCaption": "REPLY CUSTOMER",
			"otherDetails": "VIEW ALL MESSAGES"
		},
		{
			"Heading": "5 Tips to Make Your Small Business More Profitable",
			"content": "Looking for ways to make your small business more Profitable? Here are 5 tips to help you achieve that goal and build your small business.",
			"footerCaption": "READ ARTICLE",
			"otherDetails": "(2 min read)"
		},
		{
			"Heading": "Wallet balance is getting low.",
			"content": "Your wallet balance is INR 34.67. which on average will survive 4 more days. Recharge now to avoid.",
			"footerCaption": "ADD MONEY",
			"otherDetails": ""
		},
		{
			"Heading": "5 Tips to Make Your Small Business More Profitable",
			"content": "Looking for ways to make your small business more Profitable? Here are 5 tips to help you achieve that goal and build your small business.",
			"footerCaption": "READ ARTICLE",
			"otherDetails": "(2 min read)"
		}

]
